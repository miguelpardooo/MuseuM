# -*- coding: utf-8 -*-
# from odoo import http


# class Museum(http.Controller):
#     @http.route('/museum/museum', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/museum/museum/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('museum.listing', {
#             'root': '/museum/museum',
#             'objects': http.request.env['museum.museum'].search([]),
#         })

#     @http.route('/museum/museum/objects/<model("museum.museum"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('museum.object', {
#             'object': obj
#         })
