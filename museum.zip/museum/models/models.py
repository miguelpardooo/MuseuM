# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import datetime


class museum_obra(models.Model):
    _name = 'museum.obra'

    name = fields.Char(string="Título",required=True)
    tamano = fields.Char(string="Tamaño")
    ano_publicacion = fields.Integer(string="Año de publicación")
    descripcion = fields.Text(string="Descripción")
    imagen_obra = fields.Binary(string="Imagen")
    autor = fields.Many2one("museum.autor",string="Autor",ondelete="cascade")
    movimiento = fields.Many2one("museum.movimiento",string="Movimiento artístico",ondelete="cascade")
    etiquetas = fields.Many2many("museum.etiquetas",string="Etiquetas")
    antiguedad_obra = fields.Integer(string="Años de antigüedad", compute='_compute_antiguedad_obra', store=True)

    @api.constrains('ano_publicacion')
    def _check_ano_publicacion(self):
        current_year = datetime.now().year
        if self.ano_publicacion and self.ano_publicacion > current_year + 1:
            raise ValidationError("El año de publicación no puede ser superior al año actual más uno.")

    @api.depends('ano_publicacion')
    def _compute_antiguedad_obra(self):
        current_year = fields.Date.context_today(self).year
        for obra in self:
            if obra.ano_publicacion:
                obra.antiguedad_obra = current_year - obra.ano_publicacion
            else:
                obra.antiguedad_obra = 0

    def calculate_age(self):
        current_year = datetime.now().year
        for obra in self:
            if obra.ano_publicacion:
                obra_age = current_year - obra.ano_publicacion
                message = f"La obra '{obra.name}' tiene {obra_age} años desde su publicación."
                raise ValidationError(message)


class museum_autor(models.Model):
    _name = "museum.autor"

    name = fields.Char(string="Nombre completo",required="true")
    fecha_nacimiento = fields.Date(string="Fecha de nacimiento")
    nacionalidad = fields.Char(string="Nacionalidad")
    imagen_autor = fields.Binary(string="Imagen")
    obras = fields.One2many("museum.obra","autor",string="Obras")
    movimientos = fields.Many2many("museum.movimiento", string="Movimientos", relation="museum_autor_movimientos_rel")
    exposiciones = fields.One2many("museum.exposicion","autor",string="Exposiciones")
    etiquetas = fields.Many2many("museum.etiquetas",string="Etiquetas")

    @api.constrains('fecha_nacimiento')
    def _check_fecha_nacimiento(self):
        current_date = fields.Date.today()
        if self.fecha_nacimiento and self.fecha_nacimiento > current_date:
            raise ValidationError("La fecha de nacimiento no puede ser superior a la fecha actual.")

    @api.constrains('name')
    def _check_unique_name(self):
        # Verificar si ya existe un autor con el mismo nombre
        existing_autor = self.search([('name', '=', self.name), ('id', '!=', self.id)])
        if existing_autor:
            raise ValidationError("Ese autor ya ha sido introducido.")


class museum_exposicion(models.Model):
    _name = "museum.exposicion"

    name = fields.Char(string="Nombre",required="true")
    fecha = fields.Date(string="Fecha")
    descripcion = fields.Text(string="Descripción")
    autor = fields.Many2one("museum.autor",string="Autor",ondelete="cascade")
    etiquetas = fields.Many2many("museum.etiquetas",string="Etiquetas")

    # Campo Many2many para seleccionar las obras específicas del autor en la exposición
    obras_exposicion = fields.Many2many("museum.obra", string="Obras en la Exposición", domain="[('autor','=',autor)]")

    @api.constrains('name')
    def _check_unique_name(self):
        # Verificar si ya existe una exposición con el mismo nombre
        existing_exposicion = self.search([('name', '=', self.name), ('id', '!=', self.id)])
        if existing_exposicion:
            raise ValidationError("El nombre de la exposición debe ser único.")


class museum_movimiento(models.Model):
    _name = 'museum.movimiento'

    name = fields.Char(string="Nombre",required=True)
    descripcion = fields.Text(string="Descripción")
    siglo = fields.Char(string="Siglo/s")
    pais_origen = fields.Char(string="País de origen")
    obras = fields.One2many("museum.obra","movimiento",string="Obras")
    autores = fields.Many2many("museum.autor", string="Autores", relation="museum_autor_movimientos_rel")
    etiquetas = fields.Many2many("museum.etiquetas",string="Etiquetas")

    @api.constrains('name')
    def _check_unique_name(self):
        # Verificar si ya existe un movimiento con el mismo nombre
        existing_exposicion = self.search([('name', '=', self.name), ('id', '!=', self.id)])
        if existing_exposicion:
            raise ValidationError("Ese movimiento ya ha sido introducido.")


class museum_etiquetas(models.Model):
    _name = 'museum.etiquetas'

    name = fields.Char(string="Nombre",required=True)
