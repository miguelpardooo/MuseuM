# -*- coding: utf-8 -*-
{
    'name': "MuseuM",

    'summary': """
        Módulo de gestión de obras de arte, movimientos artísticos y exposiciones en un museo.""",

    'description': """
        MuseuM es un módulo completo diseñado para la gestión eficiente de obras de arte en un museo.
        Incluye funcionalidades para registrar obras, artistas, movimientos artísticos y exposiciones.
        Con MuseuM, puedes explorar la rica historia del arte y organizar exposiciones que resalten
        la diversidad de movimientos artísticos a lo largo del tiempo. Además, el módulo proporciona
        características como la asociación de etiquetas, validaciones de datos y la posibilidad de agregar
        imágenes a obras y artistas, brindando una experiencia completa de gestión de museo.
    """,

    'author': "Miguel Pardo Navarro",
    'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base'],

    # always loaded
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
        'reports/report_autor.xml',
        'reports/report_obra.xml',
        'reports/report_movimiento.xml',
        'reports/report_exposicion.xml',
        'demo/demo.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
